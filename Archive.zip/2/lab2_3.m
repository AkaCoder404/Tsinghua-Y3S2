x = 0:0.1:35;
y = besselj(0, x);
ab = [0 5];
b = fzerotx(@besselj, ab, 0);
plot(x, y);