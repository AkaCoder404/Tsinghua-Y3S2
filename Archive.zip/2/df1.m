function [y] = df1(x)
    y = 3 * x^2 - 1;
end

