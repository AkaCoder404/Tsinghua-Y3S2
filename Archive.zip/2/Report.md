# <center>report 2</center>

<center>马昕宇 2017011455</center>

## 实验一

### 实验要求

编程实现阻尼牛顿法。要求：

1. 设定合适的阻尼因子初始值$\lambda_0$及迭代判停准则；
2. 阻尼因子$\lambda$用逐次折半法更新；
3. 打印每个迭代步的最终$\lambda$值及近似解；
4. 请用其他方法（如fzero函数）验证结果，并考虑采用阻尼与不采用阻尼算法的效果差别。

用所编程序求解：

1. $x^3 - x - 1 = 0$，取$x_0=0.6$
2. $-x^3 + 5x = 0$，取$x_0=1.35$

### 算法实现

算法主要代码如下：

```matlab
disp("equation 1:");
x0 = 0.6;
xk = x0;
epsilon = 1e-5;
lambda0 = 1;
xkp = xk - lambda0 * f1(xk) / df1(xk);
while abs(f1(xk)) > epsilon || abs(xkp-xk) > epsilon
    s=f1(xk) / df1(xk);
    xkp = xk - s;
    lambda = lambda0;
    while double(abs(f1(xkp))) >= double(abs(f1(xk)))
        xkp = xk - lambda * s;
        lambda = lambda / 2;
    end
    xk = xkp;
    disp(["lambda:" num2str(lambda) "x:" num2str(xkp)]);
end
disp(xkp);
sol = fzero(@f1, x0);
disp("fzero:");
disp(sol);
```

这里设置$\lambda_0=1.0$ ,  误差阈值为$10^{-5}$，因为在调试的时候遇到一点问题，始终不会把`symbolic` 变量转换为`numeric`，所以最后函数求导用了手动的方法。

### 实验结果

输出如下：

```shell
>> lab2_2
equation 1:
    "lambda:"    "0.015625"    "x:"    "1.1406"
    "lambda:"    "1"    "x:"    "1.3668"
    "lambda:"    "1"    "x:"    "1.3263"
    "lambda:"    "1"    "x:"    "1.3247"
    1.3247
fzero:
    1.3247

equation 2:
    "lambda:"    "0.0625"    "x:"    "2.497"
    "lambda:"    "1"    "x:"    "2.272"
    "lambda:"    "1"    "x:"    "2.2369"
    "lambda:"    "1"    "x:"    "2.2361"
    2.2361
fzero:
    2.2361
```

发现在本实验中，只有第一次迭代时$lambda$进行了折半运算，之后取值一直为1，并且很快就达到了设定的误差范围之内。并且还用`fzero`函数进行了验证，与我实现的算法结果一致。

## 实验二

### 实验要求

利用2.6.3节给出的`fzerotx`程序，在MATLAB中编程求第一类的零阶贝塞尔函数$J_0(x)$的零点。$J_0(x)$在MATLAB中通过命令`besselj(0, x)`，得到。试求$J_0(x)$的前10个正的零点，并绘出函数曲线和零点的位置。

### 算法实现

按照书上内容，实现了fzerotx。代码如下：

```matlab
x = 0:0.1:35;
y = besselj(0, x);
ab = [0 5];
b = fzerotx(@besselj, ab, 0);
plot(x, y);
```

### 实验结果

实验结果如下：

![](/Users/maxinyu/Desktop/mdlife/Courses/Third_Year/NA/NALab/2/lab2_3.png)

