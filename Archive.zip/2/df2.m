function [y] = df2(x)
    y = -3 * x^2 + 5;
end

