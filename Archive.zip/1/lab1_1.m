h = logspace(-16, 0, 1000);
err = ((sin(1+h)-sin(1))./h) - cos(1);      

truncation = h/2;
rounding = eps/2 * ones(size(h,1))./h; 
fig=loglog(h, truncation, 'k-.', ...
        h, rounding, 'k--', ...
        h, abs(err), 'r-', ...
        h, truncation + rounding, 'b-');
legend('trunc\_err', 'round\_err', 'error', 'trunc+round');
xlabel('h');

set(fig, 'linewidth', 2);
axis([1e-16, 1, 1e-17, 1e1]);
ytick=logspace(-17,1,10);
ytick(1)=1e-17;
set(gca,'xtick',logspace(-16, 0, 9), 'ytick', ytick)

