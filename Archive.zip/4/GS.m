function [x, n] = GS(A, b, x0, eps)
    D = diag(diag(A));
    L = -tril(A, -1);
    U = -triu(A, 1);
    B = (D - L) \ U;
    f = (D - L) \ b;
    x = B * x0 + f;
    n = 1;
    while norm(x - x0, inf) >= eps
        x0 = x;
        x = B * x0 + f;
        n = n + 1;
    end
%     disp(n);
end