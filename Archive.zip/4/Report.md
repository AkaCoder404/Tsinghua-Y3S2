# <center>Report</center>

## 实验要求

考虑常微分方程的两点边值问题:
$$
\left\{\begin{array}{l}\varepsilon \frac{\mathrm{d}^{2} y}{\mathrm{d} x^{2}}+\frac{\mathrm{d} y}{\mathrm{d} x}=a,(0<a<1) \\ y(0)=0, y(1)=1\end{array}\right.
$$
它的精确解为
$$
y=\frac{1-a}{1-e^{-1 / \varepsilon}}\left(1-e^{-\frac{x}{\varepsilon}}\right)+a x
$$
为了把微分方程离散, 把 区间 等分, 令 
$$
x_{i}=i h, \quad(i=1,2, \cdots, n-1)
$$
得到有限差分方程
$$
\varepsilon \frac{y_{i-1}-2 y_{i}+y_{i+1}}{h^{2}}+\frac{y_{i+1}-y_{i}}{h}=a
$$
简化为
$$
(\varepsilon+h) y_{i+1}-(2 \varepsilon+h) y_{i}+\varepsilon y_{i-1}=a h^{2}
$$
从而离散后得到的线性方程组的系数矩阵与右端向量为
$$
\mathbf{A}=\left[\begin{array}{cccc}-(2 \varepsilon+h) & \varepsilon+h & & \\ 
\varepsilon & -(2 \varepsilon+h) & \varepsilon+h & & \\ 
& \varepsilon & -(2 \varepsilon+h) & \ddots & \\ 
& \ddots & \ddots & \varepsilon+h 
\\ & \varepsilon & -(2 \varepsilon+h)\end{array}\right], \mathbf{b}=\left[\begin{array}{c}a h^{2} \\ 
\vdots \\ 
a h^{2}-\varepsilon-h\end{array}\right]
$$


(1) 对$\varepsilon=1,a=\frac{1}{2},n=100$分别用雅可比, G-S 和 SOR 方法求线性方程组的解, 要求迭代结果 变化量小于0.001时停止迭代, 然后比较与精确解的误差.

(2) 对$\varepsilon=0.1,\varepsilon=0.01,\varepsilon=0.0001$考虑同样的问题.

## 算法实现

主要代码如下：

```matlab
#lab4_2.m
eps = 1.0;
a = 0.5;
n = 100;
h = 1.0 / 100;

x = (1:1:n) * h;
v = ones(n, 1) * (-2 * eps - h);
v(1) = 2 * eps + h;
A = diag(v) + diag(ones(n - 1, 1) * eps, -1) + diag(ones(n - 1, 1) * (eps + h), 1);
b = ones(n, 1) * (a * h * h);
b(n) = b(n) - eps - h;

[sol_GS, t_GS] = GS(A, b, zeros(n, 1), 0.001);
[sol_jacobi, t_jacobi] = jacobi(A, b, zeros(n, 1), 0.0001);
[sol_SOR, t_SOR] = SOR(A, b, zeros(n, 1), 0.9, 0.001);

disp(norm(x - sol_GS, 2));
disp(norm(x - sol_jacobi, 2));
disp(norm(x - sol_SOR, 2));

#GS.m
function [x, n] = GS(A, b, x0, eps)
    D = diag(diag(A));
    L = -tril(A, -1);
    U = -triu(A, 1);
    B = (D - L) \ U;
    f = (D - L) \ b;
    x = B * x0 + f;
    n = 1;
    while norm(x - x0, inf) >= eps
        x0 = x;
        x = B * x0 + f;
        n = n + 1;
    end
%     disp(n);
end

#jacobi.m
function [x, n] = jacobi(A, b, x0, eps)
    D = diag(diag(A));
    L = -tril(A, -1);
    U = -triu(A, 1);
    B = D \ (L + U);
    f = D \ b;
    x = B * x0 + f;
    n = 1;
    while norm(x - x0, inf) >= eps
        x0 = x;
        x = B * x0 + f;
        n = n + 1;
    end
%     disp(n);
end

#SOR
function [x, n] = SOR(A, b, x0, omega,eps)
    D = diag(diag(A));
    L = -tril(A, -1);
    U = -triu(A, 1);
    B = (D/omega - L) \ ((1.0/omega - 1) * D + U);
    f = (D/omega - L) \ b;
    x = B * x0 + f;
    n = 1;
    while norm(x - x0, inf) >= eps
        x0 = x;
        x = B * x0 + f;
        n = n + 1;
    end
%     disp(n);
end
```

## 实验结果

$\varepsilon=1$时，结果如下：

```shell
>> lab4_2
   48.9350

   30.5934

   49.9243
```

$\varepsilon=0.1$时，结果如下：

```shell
>> lab4_2
   34.2868

   36.8721

   40.5459
```

$\varepsilon=0.01$时，结果如下：

```shell
>> lab4_2
   38.7521

   38.7883

   38.7366
```

$\varepsilon=0.0001$时，结果如下：

```shell
>> lab4_2
   39.1897

   39.1897

   39.1884
```

