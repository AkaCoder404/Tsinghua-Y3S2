eps = 0.0001;
a = 0.5;
n = 100;
h = 1.0 / 100;

x = (1:1:n) * h;
v = ones(n, 1) * (-2 * eps - h);
v(1) = 2 * eps + h;
A = diag(v) + diag(ones(n - 1, 1) * eps, -1) + diag(ones(n - 1, 1) * (eps + h), 1);
b = ones(n, 1) * (a * h * h);
b(n) = b(n) - eps - h;

[sol_GS, t_GS] = GS(A, b, zeros(n, 1), 0.001);
[sol_jacobi, t_jacobi] = jacobi(A, b, zeros(n, 1), 0.0001);
[sol_SOR, t_SOR] = SOR(A, b, zeros(n, 1), 0.9, 0.001);

disp(norm(x - sol_GS, 2));
disp(norm(x - sol_jacobi, 2));
disp(norm(x - sol_SOR, 2));