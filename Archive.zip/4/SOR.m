function [x, n] = SOR(A, b, x0, omega,eps)
    D = diag(diag(A));
    L = -tril(A, -1);
    U = -triu(A, 1);
    B = (D/omega - L) \ ((1.0/omega - 1) * D + U);
    f = (D/omega - L) \ b;
    x = B * x0 + f;
    n = 1;
    while norm(x - x0, inf) >= eps
        x0 = x;
        x = B * x0 + f;
        n = n + 1;
    end
%     disp(n);
end